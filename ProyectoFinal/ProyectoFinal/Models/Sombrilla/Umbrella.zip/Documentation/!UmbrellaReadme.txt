1) Product Name : Umbrella obj

2) Copyright Date :February 1, 2018

3) Developers Name : uncle808us

4) Product Description :  Umbrella 3D model. Two Objects: 
	1 an Open Umbrella All systems Compatible
	2 a closed umbrella. 
	Both In object (.obj ) format.
	textures for both objects.
	This product is for use in any software that can open: 
	FBX files (.fbx) and/or Wavefront object files.(.obj)  
	UV mapped  All Quads and Tris  (non-overlapping)
	Tested in : GLC Object Player, FBX review, Cheetah 3D, and 	Poser Pro 2014 Poser Dev
		(NOT EXCLUSIVELY FOR USE IN POSER.)
	Generally scaled but not exclusively for poser figures.
	Textures Included : This product uses image maps for 			textures. 1024 x 1024
	Template (if included) : 1024 x 1024
	File Format: FBX and/or Wavefront OBJ
	This product contains: FBX and/or OBJ files.
	Polygon Count :    approx   Vertices :   approx 
	Poser Tips: Import obj with only (normals consistent checked)
		Objects if needed can be separated  in Edit Tools > 			Grouping Tool


5) System Compatibility :  All systems Compatible

6) Software Compatibility : 
	Any software that will import fbx and/or Wavefront object files. 

7) 3rd party products needed to use this product (if any) 
									NONE

8) Installation Instructions:  
	Unzip to a folder of your choice.

9) Usage Instructions: Import unzipped content to a folder of your choice. 
			For Best results set base colors to:
	Diffuse-------------------------------White(color)or supplied Texture map.
	Specular----------------------------Black or supplied Texture map.
	reflection----------------------------Black or supplied Texture map.
	transparency-----------------------Black or supplied Texture map.
	emissive-----------------------------Black or supplied Texture map.
	(Adjust as desired for your specific software package)

Material zones : 
Material zone name					Texture map name
UmbrellaOpen						UmbrellaOpen.jpg
UmbrellaClosed					UmbrellaClosed.jpg
10) Files List :
Documentation
UmbrellaClosed.jpgUmbrellaClosed.mtlUmbrellaClosed.objUmbrellaOpen.jpgUmbrellaOpen.mtlUmbrellaOpen.obj


"The developer owns the copyright and/or has the rights to
distribute all of the content contained within this ZIP file."
